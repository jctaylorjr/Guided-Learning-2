Frontal face dataset. Collected by Markus Weber at
California Institute of Technology.

Source: http://www.vision.caltech.edu/html-files/archive.html